class Cliente(): #para comenzar he creado la clase cliente 
    def __init__(self) -> None: #mediante un constructor he guardado todos los datos del cliente ademas de informar sobre el 
                                #descuento que tendrá dependiendo del pais del que sea el cliente.
        print('A continuacion debe rellenar los siguientes datos:')
        self.nombre = input('Escriba su nombre: ')
        self.apellidos = input('Escriba sus apellidos: ')
        telefonoIncorrecto = True
        while telefonoIncorrecto:
            self.numero = input('Escriba su numero de telefono: ')
            if self.numero.isnumeric():
                telefonoIncorrecto = False
            else:
                print('Por favor introduzca solo numeros')
                telefonoIncorrecto = True
        self.direccion = input('Escriba su direccion de correo: ')
        self.dni = input('Escriba su DNI: ')
        self.pais = input('De que pais eres: ').lower()
        if self.pais == 'españa':
            print('Se aplicará el iva en España: 21%')
        else:
            print(f'Se aplicará el iva de {self.pais}: 8%')

        print(f'\nTus datos se han guardado correctamente {self.nombre}\n') #las \n las utilizo para poner espacios entre frases.
        


class Productos(): #aqui he creado la clase producto en la cual hago la lista de los productos que hay disponibles con sus respectivos precios.
    def cesta(cliente):
        productos = ['mancuernas', 'barra', 'banco', 'esterilla']
        precios = [30, 100, 200, 20]
        listafinal = []
        seguirComprando = True
        while seguirComprando:
            print('\nLos productos disponibles acualmente son:\n')
            for index, item in enumerate(productos):
                print(f'\t{item} ------> {precios[index]} €') #la \t la utilizo para dejar margen en la izquierda(tabular).
            print('\n\topciones:')
            print('\n\t1. añadir producto al carrito\n\t2. mostrar el precio total\n\t3. finalizar compra\n\t4. cancelar operación\n')
            numero = input('Seleccione la opcion que quiera: ') #He printeado las opciones disponibles que puede elegir el cliente mediante numeros del 1 al 4

            if numero == '1': #Aqui hago un condicional en el que al elegir la opcion 1, mientras exista el producto que el cliente elija se le añadira a la cesta,
                            #pero si el producto no esta en la lista le apareceran 2 opciones para que el cliente elija la que quiera, si añadir otro producto o volver al menu
                noExisteProducto = True
                while noExisteProducto:
                    nombre = input('\nque producto quieres: ').lower()
                    if nombre in productos:
                        for index, item in enumerate(productos):
                            if item == nombre:
                                listafinal.append(precios[index])
                                break
                        print(f'\n\t{nombre} se ha añadido a la cesta')
                        noExisteProducto = False
                    else:
                        accion = input(
                            '\n\tNo disponemos de ese producto \n\t1 - quiere otro producto\n\t2 - volver al menú\n\t ---> ')
                        if accion == '1':
                            noExisteProducto = True
                        else:
                            noExisteProducto = False

            elif numero == '2': #En la segunda opcion se hace una suma del precio de los productos elegidos
                                # y se printea dicho precio sin iva, y de nuevo nos sale la lista de opciones.
                precioTotal = sum(listafinal)
                print(
                    f'\n\tEl precio total sin IVA es {precioTotal} €\n')

            elif numero == '3': #En la opcion 3 se finaliza la compra y se printea el precio con el iva,
                                # dependiendo del pais del que sea el cliente se aplicara un iva u otro.
                precioTotal = sum(listafinal)
                operacionIncorrecta = True
                if cliente.pais == 'españa':
                    precioTotalIva = precioTotal*1.21
                    print(
                        f'\n\tel precio total con IVA en españa es de {round(precioTotalIva,2)} €\n')
                else:
                    precioTotalIva = precioTotal*1.08
                    print(
                        f'\n\tel precio total con IVA en {cliente.pais} es de {round(precioTotalIva,2)} €\n')
                while operacionIncorrecta:
                    aceptarCompra = input(
                        '\n\t1 - confirmar compra\n\t2 - cancelar compra\n\t ---> ') #una vez te ha printeado el precio tienes dos opciones, confirmar la compra o cancelarla,
                        #si eliges confirmar la compra te pedira una confirmacion del DNI.
                    if aceptarCompra == '1':
                        DNI = input(
                            '\n\tPara confirmar tu pedido escriba su DNI: ') #Para hacer la confirmacion del DNI he echo un condicional en el que si el DNI que pone el cliente
                            #es igual al que escribio inicialmente le printeará los detalles de su pedido, en cambio si es incorrecto, le obligará a ponerlo de nuevo.
                        if DNI == cliente.dni:
                            print('\n\tGracias por su compra!\n')
                            print(
                                f'\tSu compra ha sido realizada correctamente y su precio es {round(precioTotalIva,2)} €')
                            print(
                                f'\tSe ha enviado un pdf de la factura al correo {cliente.direccion}')
                            print(
                                f'\tEl seguimiento de su pedido lo podra hacer en el telefono {cliente.numero} y el correo {cliente.direccion}\n\n')
                            seguirComprando = False
                            operacionIncorrecta = False
                            break
                        else:
                            print('\nDNI incorrecto repita la operacion')
                            operacionIncorrecta = True
                    if aceptarCompra == '2': #si el cliente elige esta ocpion se le printeara que su compra ha sido cancelada, por ello lo igualamos a false.
                        print(
                            '\n\tSu compra ha sido cancelada, le esperamos pronto\n')
                        seguirComprando = False
                        operacionIncorrecta = False
                    else:
                        print('\n\tPor favor seleccione solo 1 o 2: ')
                        operacionIncorrecta = True

            elif numero == '4': #si el cliente pulsa el numero 4 al estar igualado a False le sacará del programa por lo que su compra será cancelada
                seguirComprando = False


class Empresa: #creo una clase empresa para que nos de la bienvenida ademsas de introducir en ella la clase cliente y productos.
    def pedido(self):
        print('\nBienvenido a nuestra web\n')
        nuevoCliente = Cliente()
        Productos.cesta(nuevoCliente)


empresaMaterial = Empresa()
empresaMaterial.pedido()